import { Component } from '@angular/core';
import { Http } from '@angular/http';

@Component({
    selector : 'app',
    template : `
        <h1>App Component</h1>

        <input type="text">
    `
})
export class AppComponent
{
    
}
