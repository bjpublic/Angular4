import { Component } from '@angular/core';

@Component({
    selector : 'foo',
    template : `
        <h2>Foo Component</h2>
    `
})
export class FooComponent
{

}
