import { foo } from './lib';

foo();
