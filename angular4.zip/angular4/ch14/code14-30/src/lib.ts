export function foo() {
    console.log( "foo" );
}

export function bar() {
    console.log( "bar" );
}
