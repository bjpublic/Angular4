export class Cache
{
    data = null
}
